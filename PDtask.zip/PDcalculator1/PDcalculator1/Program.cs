﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDCalculator1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Num1 = 10, Num2 = 10;
            int userChoice = 0;
            while (userChoice != 8)
            {
                int Choice = menu(ref userChoice);
                float result = OperationResult(Num1, Num2, Choice);
                if (result == 0)
                {
                    Console.WriteLine("You Can't access any function before you creat object");
                }
                else
                {
                    Console.WriteLine("Result is: {0}", result);
                }
                Console.ReadKey();
            }
            Console.Clear();
        }
        static int menu(ref int choice)
        {
            Console.WriteLine("1- Creat Object");
            Console.WriteLine("2- Change Values of Attributes");
            Console.WriteLine("3- Addition");
            Console.WriteLine("4- Subtraction");
            Console.WriteLine("5- Multiplication");
            Console.WriteLine("6- Division");
            Console.WriteLine("7- Module");
            Console.WriteLine("8- Exit");
            Console.WriteLine();
            Console.Write("Enter Your Choosed operation Number: ");
            choice = int.Parse(Console.ReadLine());
            return choice;
        }
        static float OperationResult(float num1, float num2, int choice)
        {
            if (choice == 1)
            {
                Calculator calculator = new Calculator(num1, num2);
                Console.Write("Enter OPeration(+, -, *, /, %) : ");
                char oper = char.Parse(Console.ReadLine());

                if (oper == '+')
                {
                    return calculator.add();
                }
                else if (oper == '-')
                {
                    return calculator.subtract();
                }
                else if (oper == '*')
                {
                    return calculator.multiply();
                }
                else if (oper == '/')
                {
                    return calculator.divide();
                }
                else if (oper == '%')
                {
                    return calculator.mod();
                }
                else
                {
                    return 0;
                }

            }

            if ( choice == 2)
            {
                Console.Write("Enter Number1: ");
                num1 = float.Parse(Console.ReadLine());
                Console.Write("Enter Number2: ");
                num2 = float.Parse(Console.ReadLine());
                return 0;
            }
            else
            {
                return 0;
            }
        }
    }
}
