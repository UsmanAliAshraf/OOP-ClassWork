﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDCalculator1
{
    internal class Calculator
    {
        public float Num1;
        public float Num2;

        public Calculator(float num1, float num2)
        {
            Num1 = num1;
            Num2 = num2;

        }

        public float add()
        {
            return Num1 + Num2;
        }
        public float subtract()
        {
            return Num1 - Num2;
        }
        public float multiply()
        {
            return Num1 * Num2;
        }
        public float divide()
        {
            return Num1 / Num2;
        }
        public float mod()
        {
            return Num1 % Num2;
        }
    }
    }

