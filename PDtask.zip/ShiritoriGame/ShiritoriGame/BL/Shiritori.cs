﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShiritoriGame
{
    internal class Shiritori
    {
        private List<string> words;
        private bool game_over;

        public Shiritori()
        {
            words = new List<string>();
            game_over = false;
        }

        public List<string> Words => words;

        public bool GameOver => game_over;

        public object Play(string word)
        {
            if (game_over)
            {
                return "Game over";
            }

            if (words.Count > 0 && words.Contains(word))
            {
                game_over = true;
                return "Game over";
            }

            if (words.Count > 0 && words[words.Count - 1][words[words.Count - 1].Length - 1] != word[0])
            {
                game_over = true;
                return "Game over";
            }

            words.Add(word);
            return words;
        }

        public string Restart()
        {
            words.Clear();
            game_over = false;
            return "Game restarted";
        }
    }
}
