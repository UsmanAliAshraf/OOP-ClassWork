﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShiritoriGame
{


    class Program
    {
        static void Main(string[] args)
        {
            Shiritori game = new Shiritori();

            Console.Write("Enter a word to start the game: ");
            string input = Console.ReadLine();
            object result = game.Play(input);

            while (!game.GameOver)
            {
                if (result is List<string>)
                {
                    Console.Write("Enter a word: ");
                    input = Console.ReadLine();
                    result = game.Play(input);
                }
                else
                {
                    Console.WriteLine(result);
                    break;
                }
            }
            Console.WriteLine("Game Over!");
            Console.ReadLine();
            Console.WriteLine(game.Restart());
        }
    }
}
