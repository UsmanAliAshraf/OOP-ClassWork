﻿using System;

namespace PDCalculator2
{
    internal class Program
    {
        static Calculator calculator;
        static Calculator calculator2;


        static void Main(string[] args)
        {
            int num1 = 10, num2 = 10;

            int userChoice = 0;
            while (userChoice != 15)
            {
                int choice = menu(ref userChoice);
                if (choice == 1)
                {
                    calculator = new Calculator(num1, num2);
                    calculator2 = new Calculator(num1);
                }
                else if (choice >= 2 && choice <= 14)
                {
                    if (calculator == null)
                    {
                        Console.WriteLine("You Can't access the operation till you creat the object");
                        Console.ReadKey();
                    }
                    else
                    {
                        double result = OperationResult(calculator, choice);
                        Console.WriteLine("Result is: {0}", result);
                    }
                }
            }
            Console.Clear();
        }

        static int menu(ref int choice)
        {
            Console.WriteLine("1- Create Object");
            Console.WriteLine("2- Change Values of Attributes");
            Console.WriteLine("3- Addition");
            Console.WriteLine("4- Subtraction");
            Console.WriteLine("5- Multiplication");
            Console.WriteLine("6- Division");
            Console.WriteLine("7- Module");
            Console.WriteLine("8- SquareRoot");
            Console.WriteLine("9- Exponential");
            Console.WriteLine("10- Logarithm");
            Console.WriteLine("11- Sin");
            Console.WriteLine("12- Cos");
            Console.WriteLine("13- Tan");
            Console.WriteLine("15- Exit");
            Console.WriteLine();
            Console.Write("Enter Your Chosen operation Number: ");
            choice = int.Parse(Console.ReadLine());
            return choice;
        }

        static double OperationResult(Calculator calculator, int choice) 
        {
            switch (choice)
            {
                case 2:
                    Console.Write("Enter Number1: ");
                    float num1 = float.Parse(Console.ReadLine());
                    Console.Write("Enter Number2: ");
                    float num2 = float.Parse(Console.ReadLine());
                    calculator.ChangeValues(num1, num2); // Update values if choice is 2
                    return 0;
                case 3:
                    return calculator.add();
                case 4:
                    return calculator.subtract();
                case 5:
                    return calculator.multiply();
                case 6:
                    return calculator.divide();
                case 7:
                    return calculator.mod();
                case 8:
                    return calculator2.squareRoot();
                case 9:
                    return calculator2.exponential();
                case 10:
                    return calculator2.logarithmic();
                case 11:
                    return calculator2.Sin();
                case 12:
                    return calculator2.Cos();
                case 13:
                    return calculator2.Tan();
                default:
                    return 0;
            }
        }
    }
}