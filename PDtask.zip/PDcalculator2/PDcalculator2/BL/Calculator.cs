﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDCalculator2
{
    internal class Calculator
    {
        public float Num1;
        public float Num2;

        public Calculator(float num1, float num2)
        {
            Num1 = num1;
            Num2 = num2;

        }

        public Calculator(float num1)
        {
            Num1 = num1;
        }
        public void ChangeValues(float num1, float num2)
        {
            this.Num1 = num1;
            this.Num2 = num2;
        }
        public float add()
        {
            return Num1 + Num2;
        }
        public float subtract()
        {
            return Num1 - Num2;
        }
        public float multiply()
        {
            return Num1 * Num2;
        }
        public float divide()
        {
            return Num1 / Num2;
        }
        public float mod()
        {
            return Num1 % Num2;
        }
        public double squareRoot()
        {
            return Math.Sqrt(Num1);
        }
        public double exponential()
        {
            return Math.Exp(Num1);
        }
        public double logarithmic()
        {
            return Math.Log(Num1);
        }
        public double Sin()
        {
            return Math.Sin(Num1);
        }
        public double Cos()
        {
            return Math.Cos(Num1);
        }
        public double Tan()
        {
            return Math.Tan(Num1);
        }
    }
}

